# Kahoot Smashack V3

### WORKING AS OF 27TH AUGUST 2021

## About

Kahoot Smashack is a Kahoot hack that lets you flood Kahoot games with tons of bots. You can even control the bots to answer what you want.

## Credits

Modified by CraizyRox / Romanio0089

Script originally made by cbozey (Reddit: @XeComputerboi) (YT: CBOZEY_BOY19)

## More Info

Developed with JavaScript.

Script is running and hosted by replit.com.

The index.html and the GitHub Pages is a proxy to the replit.com project.

Version V3.0.2
